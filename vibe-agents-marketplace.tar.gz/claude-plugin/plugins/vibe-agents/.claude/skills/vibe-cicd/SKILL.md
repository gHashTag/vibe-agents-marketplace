---
name: vibe-cicd
description: CI/CD Pipeline - используй когда нужно настроить CI/CD или автоматизацию
---
