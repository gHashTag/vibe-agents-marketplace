---
name: vibe-typescript
description: TypeScript экспертиза - используй когда нужно работать с типами TypeScript
---
