---
name: vibe-mcp
description: Model Context Protocol - используй когда работаешь с MCP или интеграцией внешних сервисов
---
