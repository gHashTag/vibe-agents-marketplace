---
name: vibe-sentry
description: Мониторинг и observability - используй когда настраиваешь Sentry или мониторинг ошибок
---
