---
name: vibe-langfuse
description: LLM observability - используй когда настраиваешь Langfuse или трейсинг LLM
---
