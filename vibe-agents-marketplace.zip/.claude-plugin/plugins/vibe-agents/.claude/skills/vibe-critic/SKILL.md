---
name: vibe-critic
description: Валидация и code review - используй когда нужно проверить код или сделать ревью
---
