---
name: vibe-elizaos
description: ElizaOS Framework - используй когда создаешь плагины для Claude Code или работаешь с ElizaOS
---
