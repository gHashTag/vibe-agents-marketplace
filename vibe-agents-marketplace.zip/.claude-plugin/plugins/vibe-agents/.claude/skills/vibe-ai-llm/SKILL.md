---
name: vibe-ai-llm
description: AI/LLM провайдеры - используй когда работаешь с ИИ, LLM или интеграцией OpenRouter
---
